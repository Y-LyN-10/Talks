var fs = require('fs');

fs.readFile('some-text.txt', 'utf8', function (err, data) {
	if(err) {
		console.log(err);
	}

	console.log(data);
});

console.log('Hello, NodeJS!');